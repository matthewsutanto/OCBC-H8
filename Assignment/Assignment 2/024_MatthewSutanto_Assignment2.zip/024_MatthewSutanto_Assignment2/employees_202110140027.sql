INSERT INTO db_bank.dbo.employees (employeeNumber,lastName,firstName,extension,email,officeCode,reportsTo,jobTitle) VALUES
	 (N'C000001',N'Ronaldo',N'Cristiano',N'tst',N'ronaldo@gmail.com',N'000001',NULL,N'Manager'),
	 (N'C000002',N'Andi',N'Rudi',N'tst',N'rudi@gmail.com',N'000001',N'C000001',N'Staff Keuangan'),
	 (N'C000003',N'Sutomo',N'Roni',N'tst',N'roni@gmail.com',N'000001',N'C000001',N'Staff IT'),
	 (N'C000004',N'Vinales',N'Lorey',N'tst',N'lorey@gmail.com',N'000001',N'C000001',N'Staf HRD'),
	 (N'C000005',N'Korpus',N'Wayne',N'tst',N'wayne@gmail.com',N'000001',N'C000001',N'Staff Kasir'),
	 (N'C000006',N'Messi',N'Lionel',N'tst',N'messi@gmail.com',N'000002',NULL,N'Manager'),
	 (N'C000007',N'Sudi',N'Anto',N'tst',N'anto@gmail.com',N'000002',N'C000006',N'Staff Keuangan'),
	 (N'C000008',N'Rosero',N'Duban',N'tst',N'duban@gmail.com',N'000002',N'C000006',N'Staff IT'),
	 (N'C000009',N'De',N'Roon',N'tst',N'roon@gmail.com',N'000002',N'C000006',N'Staf HRD'),
	 (N'C000010',N'Rooney',N'Wayne',N'tst',N'rooney@gmail.com',N'000002',N'C000006',N'Staff Kasir');