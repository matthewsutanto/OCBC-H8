INSERT INTO db_bank.dbo.productlines (productLine,textDescription,htmlDescription,[image]) VALUES
	 (N'PO000001',N'Mobil',N'Ini Mobil',N'D:/Gambar/Mobil'),
	 (N'PO000002',N'Motor',N'Ini Motor',N'D:/Gambar/Motor'),
	 (N'PO000003',N'Sepeda',N'Ini Sepeda',N'D:/Gambar/Sepeda'),
	 (N'PO000004',N'Mobil Listrik',N'Ini Mobil Listrik',N'D:/Gambar/MobilListrik'),
	 (N'PO000005',N'Motor Listrik',N'Ini Motor Listrik',N'D:/Gambar/MotorListrik');