INSERT INTO db_bank.dbo.products (productCode,productName,productLine,productScale,productVendor,productDescription,quantityInStock,buyPrice,MSRP) VALUES
	 (N'P000001',N'Mobil Brio',N'PO000001',20,N'Honda',N'Ini mobil Honda Brio',200,200000000,195000000),
	 (N'P000002',N'Mobil Calya',N'PO000001',30,N'Toyota',N'Ini mobil Honda Toyota',200,190000000,185000000),
	 (N'P000003',N'Motor MX King',N'PO000002',35,N'Yamaha',N'Ini motor Yamaha MX King',300,24000000,23500000),
	 (N'P000004',N'Motor Mio',N'PO000002',40,N'Yamaha',N'Ini motor Yamaha Mio',300,16000000,15000000),
	 (N'P000006',N'Sepeda BMX 200',N'PO000003',50,N'Wimcycle',N'Ini sepeda BMX 300',200,2000000,1900000),
	 (N'P000007',N'Motor Vario Listrik',N'PO000004',50,N'Honda',N'Ini motor Honda Vario Listrik',300,25000000,24000000),
	 (N'P000008',N'Motor Mio Listrik',N'PO000004',50,N'Yamaha',N'Ini motor Yamaha Mio Listrik',300,20000000,19000000),
	 (N'P000009',N'Mobil Kona',N'PO000005',50,N'Hyundai',N'Ini mobil Hyundai Kona',300,500000000,450000000),
	 (N'P000010',N'Mobil Tesla X',N'PO000005',50,N'Tesla',N'Ini mobil Tesla X',300,1000000000,1000000000);