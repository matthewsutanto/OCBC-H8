INSERT INTO db_bank.dbo.offices (officeCode,city,phone,addressLine1,addressLine2,state,country,postalCode,territory) VALUES
	 (N'000001',N'Bandung',N'022-540142',N'TCI Blok A Nomor 32',N'TCI Blok B Nomor 45',N'Jawa Barat',N'Indonesia',N'42423',N'Jawa'),
	 (N'000002',N'Jakarta',N'021-540128',N'Jalan kemayoran nomor 2',N'Tanjung Duren Nomor 28',N'DKI Jakarta',N'Indonesia',N'52622',N'Jawa'),
	 (N'000003',N'Surabaya',N'023-54257',N'Jalan Ahmad Yani nomor 61',N'Jalan Darmo nomor 8',N'Jawa Timur',N'Indonesia',N'42341',N'Jawa'),
	 (N'000004',N'Semarang',N'024-43280',N'Jalan Citarum nomor 87',N'Jalan Dr. Cipto nomor 35',N'Jawa Tengah',N'Indonesia',N'43215',N'Jawa'),
	 (N'000005',N'Makassar',N'027-43157',N'Jalan Sultan Hasanudin nomor 51',N'Jalan Bebas nomor 98',N'Sulawesi Selatan',N'Indonesia',N'78941',N'Sulawesi');