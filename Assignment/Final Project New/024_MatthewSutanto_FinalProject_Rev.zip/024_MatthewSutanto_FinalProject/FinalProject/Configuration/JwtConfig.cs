namespace FinalProject.Configuration
{
    public class JwtConfig
    {
        public string secret { get; set; }
    }
}